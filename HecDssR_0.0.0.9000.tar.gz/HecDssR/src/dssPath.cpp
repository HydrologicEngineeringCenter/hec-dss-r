#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <Rcpp.h>
#include "recordType.h"
#include "dssPath.h"

const std::vector<RecordType> DssPath::timeSeriesFamily = {
    RecordType::IrregularTimeSeries, 
    RecordType::RegularTimeSeries, 
    RecordType::RegularTimeSeriesProfile
};

DssPath::DssPath(const std::string& path, RecordType recType) 
    : recType(recType) {
    if (path.length() < 7 || path.front() != '/' || path.back() != '/') {
        Rcpp::stop("Invalid DSS Path: '" + path + "'");
    }
    std::string trimmedPath = path.substr(1, path.length() - 2);
    split(trimmedPath, '/');
    if (parts.size() >= 6) {
        A = parts[0];
        B = parts[1];
        C = parts[2];
        D = parts[3];
        E = parts[4];
        F = parts[5];
    }
}

bool DssPath::operator==(const DssPath& other) const {
    return toString() == other.toString();
}

std::string DssPath::toString() const {
    return "/" + A + "/" + B + "/" + C + "/" + D + "/" + E + "/" + F + "/";
}

DssPath DssPath::pathWithoutDate() const {
    std::string s = "/" + A + "/" + B + "/" + C + "//" + E + "/" + F + "/";
    return DssPath(s, recType);
}

bool DssPath::isTimeSeries() const {
    return std::find(timeSeriesFamily.begin(), timeSeriesFamily.end(), recType) != timeSeriesFamily.end();
}

void DssPath::print() const {
    Rcpp::Rcout << "a: " << A << std::endl;
    Rcpp::Rcout << "b: " << B << std::endl;
    Rcpp::Rcout << "c: " << C << std::endl;
    Rcpp::Rcout << "d: " << D << std::endl;
    Rcpp::Rcout << "e: " << E << std::endl;
    Rcpp::Rcout << "f: " << F << std::endl;
}

std::string DssPath::getD() const {
    return D;
}

void DssPath::setD(const std::string& d) {
    D = d;
}

void DssPath::split(const std::string& str, char delimiter) {
    parts.clear(); // Clear the parts vector before splitting
    size_t start = 0;
    size_t end = str.find(delimiter);
    while (end != std::string::npos) {
        parts.push_back(str.substr(start, end - start));
        start = end + 1;
        end = str.find(delimiter, start);
    }
    parts.push_back(str.substr(start, end));
}
