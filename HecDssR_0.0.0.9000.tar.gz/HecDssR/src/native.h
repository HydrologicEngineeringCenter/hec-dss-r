#ifndef NATIVE_H
#define NATIVE_H

#include <Windows.h>
#include <iostream>
#include <ctime>
#include <tuple>
#include <vector>
#include <string>
#include <Rcpp.h>

extern "C" {
#include "hecdss.h"
}

extern double DSS_UNDEFINED_VALUE;

dss_file* hecDssOpen(const std::string& filename);

int hecDssGetVersion(dss_file* dss);

std::tuple<std::vector<std::string>, std::vector<int>> hecDssCatalog(dss_file* dss, std::string filter = "");

std::tuple<Rcpp::Datetime, Rcpp::Datetime> get_date_time_range_full(dss_file* dss, std::string pathname, int boolFullSet);

std::tuple<int, int> get_ts_sizes(dss_file* dss, std::string pathname, 
                        std::string startDate, std::string startTime, 
                        std::string endDate, std::string endTime);

void close_dss(dss_file* dss);

#endif // NATIVE_H
