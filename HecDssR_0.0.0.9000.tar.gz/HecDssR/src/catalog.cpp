#include "catalog.h"
#include <algorithm>
#include <sstream>
#include <iomanip>

Catalog::Catalog(const std::vector<std::string>& uncondensed_paths, const std::vector<int>& recordTypes) 
    : uncondensed_paths(uncondensed_paths), rawRecordTypes(recordTypes) {
    __create_condensed_catalog();
}

RecordType Catalog::get_record_type(const std::string& pathname) {
    std::string lower_pathname = to_lower(pathname);
    if (recordTypeDict.find(lower_pathname) != recordTypeDict.end()) {
        return recordTypeDict[lower_pathname];
    } else {
        DssPath path(pathname, RecordType::Unknown);
        return recordTypeDict[to_lower(path.pathWithoutDate().toString())];
    }
}

void Catalog::print() const {
    for (const auto& ds : items) {
        std::cout << ds.toString() << std::endl;
    }
}

std::vector<DssPath>::iterator Catalog::begin() {
    return items.begin();
}

std::vector<DssPath>::iterator Catalog::end() {
    return items.end();
}

void Catalog::__create_condensed_catalog() {
    for (size_t i = 0; i < uncondensed_paths.size(); ++i) {
        std::string rawPath = uncondensed_paths[i];
        RecordType recordType = RecordTypeFromInt(rawRecordTypes[i]);
        DssPath path(rawPath, recordType);

        if (path.isTimeSeries()) {
            std::string cleanPath = path.pathWithoutDate().toString();
            recordTypeDict[to_lower(cleanPath)] = recordType;
            if (path.getD() != "TS-Pattern") {
                std::vector<std::tm>& tsRecords = timeSeriesDictNoDates[to_lower(cleanPath)];
                std::tm t = {};
                std::istringstream ss(path.getD());
                ss >> std::get_time(&t, "%d%b%Y");
                tsRecords.push_back(t);
            }
        } else if (recordType == RecordType::PairedData || recordType == RecordType::Grid || 
                   recordType == RecordType::Text || recordType == RecordType::LocationInfo || 
                   recordType == RecordType::Array) {
            recordTypeDict[to_lower(path.toString())] = recordType;
            items.push_back(path);
        } else {
            throw std::runtime_error("unsupported record_type: " + std::to_string(static_cast<int>(recordType)));
        }
    }

    for (auto& pair : timeSeriesDictNoDates) {
        std::vector<std::tm>& dateList = pair.second;
        std::sort(dateList.begin(), dateList.end(), [](const std::tm& a, const std::tm& b) {
            return std::mktime(const_cast<std::tm*>(&a)) < std::mktime(const_cast<std::tm*>(&b));
        });

        std::string condensedDpart = format_date(dateList.front());
        if (dateList.size() > 1) {
            condensedDpart += "-" + format_date(dateList.back());
        }

        RecordType rt = recordTypeDict[pair.first];
        DssPath p(pair.first, rt);
        p.setD(condensedDpart);
        items.push_back(p);
    }
}

std::string Catalog::to_lower(const std::string& str) const {
    std::string lower_str = str;
    std::transform(lower_str.begin(), lower_str.end(), lower_str.begin(), ::tolower);
    return lower_str;
}

std::string Catalog::format_date(const std::tm& date) const {
    char buffer[11];
    strftime(buffer, sizeof(buffer), "%d%b%Y", &date);
    return std::string(buffer);
}
