// filepath: /c:/projects/hec-dss-r/src/recordType.h
#ifndef RECORDTYPE_H
#define RECORDTYPE_H

#include <string>
#include <vector>

enum class RecordType {
    Unknown = 0,
    RegularTimeSeriesProfile = 1,
    RegularTimeSeries = 2,
    IrregularTimeSeries = 3,
    PairedData = 4,
    Text = 5,
    Grid = 6,
    Tin = 7,
    LocationInfo = 8,
    Array = 9
};

extern const std::vector<std::string> SUPPORTED_RECORD_TYPES;

RecordType RecordTypeFromInt(int recType);

#endif // RECORDTYPE_H
