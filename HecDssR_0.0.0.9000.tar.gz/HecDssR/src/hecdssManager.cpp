// hecdss.cpp
// [[Rcpp::depends(Rcpp)]]
// [[Rcpp::plugins("cpp11")]]
#include <Rcpp.h>
#include <Windows.h>
#include <iostream>
#include <tuple>
#include "dssPath.h" // Include the DssPath class
#include "recordType.h" // Include the RecordType enum
#include "native.h" // Include the hecDssOpen function
#include "dateConverter.h" // Include the date_times_from_julian_array function
#include "catalog.h" // Include the Catalog class

class HecDssManager {
public:
HecDssManager(std::string filename) : filename_(filename), closed_(false) {
    dss = hecDssOpen(filename);
}

~HecDssManager() {
    this->close();
}

void close() {
    closed_ = true;
    close_dss(dss);
}

Rcpp::DataFrame get(std::string pathname, Rcpp::Nullable<Rcpp::Datetime> start_datetime = R_NilValue, Rcpp::Nullable<Rcpp::Datetime> end_datetime = R_NilValue) {
    pathname = std::string(pathname);
    RecordType type = this->GetRecordType(pathname);
    // gets various types of data from the current DSS files

    // Args:
    //     pathname (str): dss pathname
    //     start_datetime (datetime): start date for query
    //     end_datetime (datetime): end date for the query

    // Returns:
    //     varies: RegularTimeSeries, PairedData, Grid, or Array.  
    if (type == RecordType::RegularTimeSeries || type == RecordType::IrregularTimeSeries) {
        std::string new_pathname = DssPath(pathname).pathWithoutDate().toString();
        return this->GetTimeseries(new_pathname, start_datetime, end_datetime, static_cast<int>(type));
    } else if (type == RecordType::PairedData) {
        return this->GetPairedData(pathname);
    } else if (type == RecordType::Grid) {
        return this->GetGriddedData(pathname);
    } else if (type == RecordType::Array) {
        return this->GetArray(pathname);
    } else if (type == RecordType::LocationInfo) {
        return this->GetLocationInfo(pathname);
    }
    return Rcpp::DataFrame::create();
}

void put(Rcpp::DataFrame df) { 
    std::string pathname = df.attr("PathName");
    int numTypes = df.attr("RecordType");
    RecordType type = static_cast<RecordType>(numTypes);
    // gets various types of data from the current DSS files

    // Args:
    //     pathname (str): dss pathname
    //     start_datetime (datetime): start date for query
    //     end_datetime (datetime): end date for the query

    // Returns:
    //     varies: RegularTimeSeries, PairedData, Grid, or Array.  
    if (type == RecordType::RegularTimeSeries) {
        std::string new_pathname = DssPath(pathname).pathWithoutDate().toString();
        this->PutRegularTimeseries(df);
    } else if(type == RecordType::IrregularTimeSeries) {
        this->PutIrregularTimeSeries(df);
    }
    else{
        Rcpp::stop("unsupported record_type: " + std::to_string(static_cast<int>(type)) + ". Expected types are: RegularTimeSeries, IrregularTimeSeries");
    }
    catalog_ = NULL;
}

private:
    //Native native_;
    Catalog* catalog_;
    std::string filename_;
    bool closed_;
    dss_file* dss;

    RecordType GetRecordType(const std::string& pathname) {
        if (!catalog_) {
            catalog_ = get_catalog(dss);
        }
        //return catalog_->get_record_type(pathname);
        return RecordType::RegularTimeSeries;
    }

    Catalog* get_catalog(dss_file* dss) {
        // Implement this function to return a Catalog instance
        // This is a placeholder implementation
        std::vector<std::string> uncondensed_paths; // Populate this with actual paths
        std::vector<int> recordTypes; // Populate this with actual record types
        auto result = hecDssCatalog(dss);
        uncondensed_paths = std::get<0>(result);
        recordTypes = std::get<1>(result);
        return new Catalog(uncondensed_paths, recordTypes);
    }

    void PutRegularTimeseries(Rcpp::DataFrame df) {
        // Extract attributes from the DataFrame
        std::string pathname = Rcpp::as<std::string>(df.attr("PathName"));
        std::string units = Rcpp::as<std::string>(df.attr("Units"));
        std::string data_type = Rcpp::as<std::string>(df.attr("Type"));

        // Extract the first Datetime object from the data frame
        Rcpp::DatetimeVector timeVector = df["Time"];
        Rcpp::Datetime startDateTime = timeVector[0];

        // Format the Datetime object to get the start date and time
        std::string startDate = format_datetime(startDateTime, "%d%b%Y");
        std::string startTime = format_datetime(startDateTime, "%H:%M:%S");

        // Extract the values and quality arrays from the data frame
        Rcpp::NumericVector valueArray = df["Value"];
        Rcpp::IntegerVector qualityArray = df.containsElementNamed("Quality") ? df["Quality"] : Rcpp::IntegerVector(valueArray.size(), 0);

        // Call the store_timeseries function to store the data in the DSS file
        int status = hec_dss_tsStoreRegular(dss, pathname.c_str(), 
                                            startDate.c_str(), startTime.c_str(), 
                                            valueArray.begin(), valueArray.size(), 
                                            qualityArray.begin(), qualityArray.size(), 
                                            false, units.c_str(), data_type.c_str());

        if (status != 0) {
            Rcpp::stop("Error storing regular time series data");
        }
    }

    void PutIrregularTimeSeries(Rcpp::DataFrame df) {
        // Extract attributes from the DataFrame
        std::string pathname = Rcpp::as<std::string>(df.attr("PathName"));
        std::string units = Rcpp::as<std::string>(df.attr("Units"));
        std::string data_type = Rcpp::as<std::string>(df.attr("Type"));
        int julian_base_date = Rcpp::as<int>(df.attr("julian_base_date"));
        int time_granularity_seconds = Rcpp::as<int>(df.attr("time_granularity_seconds"));

        // Extract time and value columns
        std::vector<Rcpp::Datetime> times = df["Time"];
        std::vector<double> values = df["Value"];

        // Convert times to Julian dates
        Rcpp::Datetime start_date_base = Rcpp::Datetime("1900-01-01 00:00:00");
        start_date_base = start_date_base + Rcpp::Datetime(julian_base_date * 86400.0); // Convert days to seconds
        std::string startDate = format_datetime(start_date_base, "%d%b%Y");
        std::string startTime = format_datetime(start_date_base, "%H:%M:%S");

        std::vector<int> quality = df.containsElementNamed("Quality") ? Rcpp::as<std::vector<int>>(df["Quality"]) : std::vector<int>(values.size(), 0);
        std::vector<int> julian_times = julian_array_from_date_times(times, time_granularity_seconds, start_date_base);

        if (*std::max_element(julian_times.begin(), julian_times.end()) >= 2147483647) {
            Rcpp::stop("Julian times contains value larger than 2147483647, increase granularity or change start_date_base to fix.");
        }

        int status = hec_dss_tsStoreIregular(
            dss,
            pathname.c_str(),
            startDate.c_str(),
            julian_times.data(),
            time_granularity_seconds,
            values.data(),
            values.size(),
            quality.data(),
            quality.size(),
            false,
            units.c_str(),
            data_type.c_str()
        );

        if (status != 0) {
            Rcpp::stop("Error storing irregular time series data");
        }
    }

    Rcpp::DataFrame GetTimeseries(const std::string& pathname, Rcpp::Nullable<Rcpp::Datetime> startDateTime, Rcpp::Nullable<Rcpp::Datetime> endDateTime, int recordType) {
        Rcpp::Datetime startDateTimeVal;
        Rcpp::Datetime endDateTimeVal;

        // Retrieve date-time range if startDateTime or endDateTime is not provided
        if (startDateTime.isNull() || endDateTime.isNull()) {
            auto date_time_range = get_date_time_range_full(dss, pathname, 1);
            
            if (startDateTime.isNull()) {
                startDateTimeVal = std::get<0>(date_time_range);
            } else {
                startDateTimeVal = Rcpp::Datetime(startDateTime);
            }
            if (endDateTime.isNull()) {
                endDateTimeVal = std::get<1>(date_time_range);
            } else {
                endDateTimeVal = Rcpp::Datetime(endDateTime);
            }
        } else {
            startDateTimeVal = Rcpp::Datetime(startDateTime);
            endDateTimeVal = Rcpp::Datetime(endDateTime);
        }
        // Rcpp::Rcout << "Start Time Val: " << startDateTimeVal << std::endl;
        // Rcpp::Rcout << "End Date Val: " << endDateTimeVal << std::endl;

        std::string startDate = format_datetime(startDateTimeVal , "%d%b%Y");
        std::string startTime = format_datetime(startDateTimeVal , "%H:%M:%S");
        std::string endDate = format_datetime(endDateTimeVal , "%d%b%Y");
        std::string endTime = format_datetime(endDateTimeVal , "%H:%M:%S");

        Rcpp::Rcout << startDate << std::endl;
        Rcpp::Rcout << startTime << std::endl;
        Rcpp::Rcout << endDate << std::endl;
        Rcpp::Rcout << endTime << std::endl;

        // Retrieve time series sizes
        auto ts_sizes = get_ts_sizes(dss, pathname, startDate, startTime, endDate, endTime);
        int arraySize = std::get<0>(ts_sizes);

        std::vector<int> timeArray(arraySize);
        std::vector<double> valueArray(arraySize);
        int numberValuesRead = 0;
        std::vector<int> quality(arraySize);
        int julianBaseDate = 0;
        int timeGranularitySeconds = 0;
        char units[50];
        char type[50];

        int status = hec_dss_tsRetrieve(dss, pathname.c_str(), 
                                        startDate.c_str(), startTime.c_str(), 
                                        endDate.c_str(), endTime.c_str(), 
                                        timeArray.data(), valueArray.data(), arraySize, 
                                        &numberValuesRead, quality.data(), arraySize, 
                                        &julianBaseDate, &timeGranularitySeconds, 
                                        units, 40, type, 40);

        if (status != 0) {
            Rcpp::stop("Error retrieving time series data");
        }

        // Convert timeArray to Rcpp::Datetime
        std::vector<Rcpp::Datetime> datetimeArray = date_times_from_julian_array(timeArray, timeGranularitySeconds, julianBaseDate);

        // Filter out undefined values
        std::vector<Rcpp::Datetime> filteredTimeArray;
        std::vector<double> filteredValueArray;
        for (int i = 0; i < numberValuesRead; ++i) {
            //if (valueArray[i] != DSS_UNDEFINED_VALUE) {
                filteredTimeArray.push_back(datetimeArray[i]);
                filteredValueArray.push_back(valueArray[i]);
            //}
        }

        Rcpp::DataFrame df = Rcpp::DataFrame::create(Rcpp::Named("Time") = filteredTimeArray,
                                                    Rcpp::Named("Value") = filteredValueArray);

        // Set Units and Type as attributes
        df.attr("Units") = units;
        df.attr("Type") = type;
        df.attr("julian_base_date") = julianBaseDate;
        df.attr("time_granularity_seconds") = timeGranularitySeconds;
        df.attr("PathName") = pathname;
        df.attr("RecordType") = recordType;

        return df;
    }

    Rcpp::DataFrame GetPairedData(const std::string& pathname) {
        // Implement this function to get paired data
        // This is a placeholder implementation
        return Rcpp::DataFrame::create();
    }

    Rcpp::DataFrame GetGriddedData(const std::string& pathname) {
        // Implement this function to get gridded data
        // This is a placeholder implementation
        return Rcpp::DataFrame::create();
    }

    Rcpp::DataFrame GetArray(const std::string& pathname) {
        // Implement this function to get array data
        // This is a placeholder implementation
        return Rcpp::DataFrame::create();
    }

    Rcpp::DataFrame GetLocationInfo(const std::string& pathname) {
        // Implement this function to get location info
        // This is a placeholder implementation
        return Rcpp::DataFrame::create();
    }
};

// [[Rcpp::export]]
Rcpp::XPtr<HecDssManager> openHecDss(std::string filename) {
    HecDssManager* ptr = new HecDssManager(filename);
    return Rcpp::XPtr<HecDssManager>(ptr, true);
}

// [[Rcpp::export]]
Rcpp::DataFrame getDataFrame(Rcpp::XPtr<HecDssManager> ptr, std::string pathname, Rcpp::Nullable<Rcpp::Datetime> start_datetime = R_NilValue, Rcpp::Nullable<Rcpp::Datetime> end_datetime = R_NilValue) {
    return ptr->get(pathname, start_datetime, end_datetime);
}

// [[Rcpp::export]]
void putDataFrame(Rcpp::XPtr<HecDssManager> ptr, Rcpp::DataFrame df) { 
    ptr->put(df);
}

// [[Rcpp::export]]
void closeHecDss(Rcpp::XPtr<HecDssManager> ptr) {
    ptr->close();
}
