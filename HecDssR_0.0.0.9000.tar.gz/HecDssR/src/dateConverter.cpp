#include <Rcpp.h>
#include <Windows.h>
#include <iostream>
#include <ctime>


// Function to format Rcpp::Datetime to string using strftime
std::string format_datetime(const Rcpp::Datetime& datetime, const char* format="%Y-%m-%d %H:%M:%S") {
    // char buffer[100];
    // std::time_t time = static_cast<std::time_t>(datetime.getFractionalTimestamp());
    // std::tm tm_info;
    // gmtime_s(&tm_info, &time); // Use gmtime_s for thread-safe conversion
    // std::strftime(buffer, sizeof(buffer), format, &tm_info);
    double timestamp = datetime.getFractionalTimestamp();
    time_t t = (time_t) timestamp;
    // Format datetime
    char buffer[80];
    strftime(buffer, sizeof(buffer), format, localtime(&t));
    return std::string(buffer);
}


// Function to convert from DSS integer datetime array to Rcpp::Datetime array
std::vector<Rcpp::Datetime> date_times_from_julian_array(const std::vector<int>& times_julian, 
    int time_granularity_seconds, 
    int julian_base_date) {
    if (times_julian.empty()) {
    Rcpp::stop("Time Series Times array was empty. Something didn't work right in DSS.");
    }

    std::vector<Rcpp::Datetime> times;
    Rcpp::Datetime baseDateTime("1900-01-01 23:00:00");
    baseDateTime = baseDateTime - Rcpp::Datetime(2 * 86400); // Subtract one day


    for (int t : times_julian) {
    double delta = 0;
    if (time_granularity_seconds == 1) {  // 1 second
    delta = t;
    } else if (time_granularity_seconds == 60) {  // 60 seconds per minute
    delta = static_cast<double>(t) * 60;
    } else if (time_granularity_seconds == 3600) {  // 3600 seconds per hour
    delta = static_cast<double>(t) * 3600;
    } else if (time_granularity_seconds == 86400) {  // 86400 seconds per day
    delta = static_cast<double>(t) * 86400;
    }

    Rcpp::Datetime datetime = baseDateTime + Rcpp::Datetime(delta) + Rcpp::Datetime(static_cast<double>(julian_base_date) * 86400);
    times.push_back(datetime);
    }

    return times;
}
// Function to convert from Rcpp::Datetime array to DSS integer datetime array
std::vector<int> julian_array_from_date_times(const std::vector<Rcpp::Datetime>& date_times, 
                                              int time_granularity_seconds = 60, 
                                              const Rcpp::Datetime& start_date_base = Rcpp::Datetime("1900-01-01 00:00:00")) {
    if (date_times.empty()) {
        Rcpp::stop("Time Series Times array was empty. Something didn't work right in DSS.");
    }

    Rcpp::Datetime adjusted_start_date_base = start_date_base - Rcpp::Datetime(1 * 86400); // Subtract one day
    std::vector<int> julian_array;

    for (const auto& datetime : date_times) {
        double delta_seconds = datetime.getFractionalTimestamp() - adjusted_start_date_base.getFractionalTimestamp();
        int julian_time = static_cast<int>(delta_seconds / time_granularity_seconds);
        julian_array.push_back(julian_time);
    }

    return julian_array;
}
