// filepath: /c:/projects/hec-dss-r/src/recordType.cpp
#include <iostream>
#include <vector>

enum class RecordType {
    Unknown = 0,
    RegularTimeSeriesProfile = 1,
    RegularTimeSeries = 2,
    IrregularTimeSeries = 3,
    PairedData = 4,
    Text = 5,
    Grid = 6,
    Tin = 7,
    LocationInfo = 8,
    Array = 9
};

const std::vector<std::string> SUPPORTED_RECORD_TYPES = {
    "IrregularTimeSeries",
    "RegularTimeSeries",
    "PairedData",
    "GriddedData",
    "ArrayContainer"
};

RecordType RecordTypeFromInt(int recType) {
    RecordType rval = RecordType::Unknown;

    if (90 <= recType && recType <= 93) {
        rval = RecordType::Array;
    } else if (100 <= recType && recType < 110) {
        if (recType == 102 || recType == 107) {
            rval = RecordType::RegularTimeSeriesProfile;
        } else {
            rval = RecordType::RegularTimeSeries;
        }
    } else if (110 <= recType && recType < 200) {
        rval = RecordType::IrregularTimeSeries;
    } else if (200 <= recType && recType < 300) {
        rval = RecordType::PairedData;
    } else if (300 <= recType && recType < 400) {
        rval = RecordType::Text;
    } else if (400 <= recType && recType < 450) {
        rval = RecordType::Grid;
    } else if (recType == 450) {
        rval = RecordType::Tin;
    } else if (recType == 20) {
        rval = RecordType::LocationInfo;
    }

    return rval;
}
