#ifndef CATALOG_H
#define CATALOG_H

#include <iostream>
#include <vector>
#include <map>
#include <ctime>
#include "recordType.h"
#include "dsspath.h"

class Catalog {
public:
    Catalog(const std::vector<std::string>& uncondensed_paths, const std::vector<int>& recordTypes);

    RecordType get_record_type(const std::string& pathname);

    void print() const;

    std::vector<DssPath>::iterator begin();
    std::vector<DssPath>::iterator end();

private:
    std::vector<std::string> uncondensed_paths;
    std::vector<int> rawRecordTypes;
    std::map<std::string, std::vector<std::tm>> timeSeriesDictNoDates;
    std::map<std::string, RecordType> recordTypeDict;
    std::vector<DssPath> items;

    void __create_condensed_catalog();

    std::string to_lower(const std::string& str) const;
    std::string format_date(const std::tm& date) const;
};

#endif // CATALOG_H
