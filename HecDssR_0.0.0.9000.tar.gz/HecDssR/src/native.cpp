#include <Rcpp.h>
#include <Windows.h>
#include <iostream>
#include <ctime>
#include <tuple>
#include "dateConverter.h"

extern "C" {
#include "hecdss.h"
}

double DSS_UNDEFINED_VALUE = -340282346638528859811704183484516925440.000000;

dss_file* hecDssOpen(const std::string& filename){
    dss_file* dss = nullptr;
    hec_dss_open(filename.c_str(), &dss);
    return dss;
}

int hecDssGetVersion(dss_file* dss){
    return hec_dss_getVersion(dss);
}


// List retrieve_ts_info(dss_file* dss, std::string pathname) {
//     const int unitsLength = 40;
//     const int typeLength = 40;
//     char units[unitsLength] = "";
//     char type[typeLength] = "";

//     int status = hec_dss_tsRetrieveInfo(dss, pathname.c_str(), units, unitsLength, type, typeLength);
//     if (status != 0) {
//         Rcpp::stop("Error retrieving time series info");
//     }

//     return Rcpp::List::create(Rcpp::Named("units") = std::string(units),
//                               Rcpp::Named("type") = std::string(type));
// }

std::tuple<std::vector<std::string>, std::vector<int>> hecDssCatalog(dss_file* dss, std::string filter = "") {
    int count = hec_dss_record_count(dss);
    // int pathBufferSize = hec_dss_CONSTANT_MAX_PATH_SIZE;
    int pathBufferSize = 200;
    
    std::vector<char> c_rawCatalog(count * pathBufferSize);
    std::vector<int> recordTypes(count);
    
    int numRecords = hec_dss_catalog(dss, c_rawCatalog.data(), recordTypes.data(), filter.c_str(), count, pathBufferSize);
    
    std::vector<std::string> pathNameList;
    std::vector<int> recordTypeList;
    for (int i = 0; i < numRecords; ++i) {
        std::string s(c_rawCatalog.data() + i * pathBufferSize, pathBufferSize);
        s.erase(std::find(s.begin(), s.end(), '\0'), s.end()); // Remove null characters
        pathNameList.push_back(s);
        recordTypeList.push_back(recordTypes[i]);
    }
    
    return std::make_tuple(pathNameList, recordTypeList);
}

std::tuple<Rcpp::Datetime, Rcpp::Datetime> get_date_time_range_full(dss_file* dss, std::string pathname, int boolFullSet) {
    int firstValidJulian = 0;
    int firstSeconds = 0;
    int lastValidJulian = 0;
    int lastSeconds = 0;

    int status = hec_dss_tsGetDateTimeRange(dss, pathname.c_str(), boolFullSet, &firstValidJulian, &firstSeconds, &lastValidJulian, &lastSeconds);
    if (status != 0) {
        Rcpp::stop("Error retrieving full date-time range");
    }

    std::vector<int> firstSecondsVec = {firstSeconds};
    std::vector<int> lastSecondsVec = {lastSeconds};

    Rcpp::Datetime first = date_times_from_julian_array(firstSecondsVec, 1, firstValidJulian)[0];
    Rcpp::Datetime last = date_times_from_julian_array(lastSecondsVec, 1, lastValidJulian)[0];


    return std::make_tuple(first, last);
}

std::tuple<int, int> get_ts_sizes(dss_file* dss, std::string pathname, 
                        std::string startDate, std::string startTime, 
                        std::string endDate, std::string endTime) {
    int numberValues = 0;
    int qualityElementSize = 0;

    int status = hec_dss_tsGetSizes(dss, pathname.c_str(), 
                                    startDate.c_str(), startTime.c_str(), 
                                    endDate.c_str(), endTime.c_str(), 
                                    &numberValues, &qualityElementSize);
    if (status != 0) {
        Rcpp::stop("Error retrieving time series sizes");
    }

    return std::make_tuple(numberValues, qualityElementSize);
}

// // [[Rcpp::export]]
// Rcpp::DataFrame get_timeseries(Rcpp::XPtr<dss_file> dss, std::string pathname, 
//                                Rcpp::Nullable<Rcpp::Datetime> startDateTime = R_NilValue, 
//                                Rcpp::Nullable<Rcpp::Datetime> endDateTime = R_NilValue) {
//     Rcpp::Datetime startDateTimeVal;
//     Rcpp::Datetime endDateTimeVal;

//     // Retrieve date-time range if startDateTime or endDateTime is not provided
//     if (startDateTime.isNull() || endDateTime.isNull()) {
//         Rcpp::List date_time_range = get_date_time_range_full(dss, pathname, 1);
        
//         if (startDateTime.isNull()) {
//             startDateTimeVal = date_time_range["first"];
//         } else {
//             startDateTimeVal = Rcpp::Datetime(startDateTime);
//         }
//         if (endDateTime.isNull()) {
//             endDateTimeVal = date_time_range["last"];
//         } else {
//             endDateTimeVal = Rcpp::Datetime(endDateTime);
//         }
//     } else {
//         startDateTimeVal = Rcpp::Datetime(startDateTime);
//         endDateTimeVal = Rcpp::Datetime(endDateTime);
//     }
//     // Rcpp::Rcout << "Start Time Val: " << startDateTimeVal << std::endl;
//     // Rcpp::Rcout << "End Date Val: " << endDateTimeVal << std::endl;

//     std::string startDate = format_datetime(startDateTimeVal , "%d%b%Y");
//     std::string startTime = format_datetime(startDateTimeVal , "%H:%M:%S");
//     std::string endDate = format_datetime(endDateTimeVal , "%d%b%Y");
//     std::string endTime = format_datetime(endDateTimeVal , "%H:%M:%S");

//     // Retrieve time series sizes
//     Rcpp::List ts_sizes = get_ts_sizes(dss, pathname, startDate, startTime, endDate, endTime);
//     int arraySize = Rcpp::as<int>(ts_sizes["numberValues"]);

//     std::vector<int> timeArray(arraySize);
//     std::vector<double> valueArray(arraySize);
//     int numberValuesRead = 0;
//     std::vector<int> quality(arraySize);
//     int julianBaseDate = 0;
//     int timeGranularitySeconds = 0;
//     char units[50];
//     char type[50];

//     // // Retrieve time series info
//     // Rcpp::List tsInfo = retrieve_ts_info(dss, pathname);
//     // std::string units = Rcpp::as<std::string>(tsInfo["units"]);
//     // std::string type = Rcpp::as<std::string>(tsInfo["type"]);

//     // Debugging output
//     Rcpp::Rcout << "Array Sizes: " << arraySize << std::endl;
//     Rcpp::Rcout << "Start Time: " << startTime << std::endl;
//     Rcpp::Rcout << "Start Date: " << startDate << std::endl;
//     Rcpp::Rcout << "End Time: " << endTime << std::endl;
//     Rcpp::Rcout << "End Date: " << endDate << std::endl;

//     int status = hec_dss_tsRetrieve(dss.get(), pathname.c_str(), 
//                                     startDate.c_str(), startTime.c_str(), 
//                                     endDate.c_str(), endTime.c_str(), 
//                                     timeArray.data(), valueArray.data(), arraySize, 
//                                     &numberValuesRead, quality.data(), arraySize, 
//                                     &julianBaseDate, &timeGranularitySeconds, 
//                                     units, 40, type, 40);

//     if (status != 0) {
//         Rcpp::Rcout << "Error code: " << status << std::endl;
//         Rcpp::Rcout << "Pathname: " << pathname << std::endl;
//         Rcpp::Rcout << "Start Date: " << startDate << std::endl;
//         Rcpp::Rcout << "Start Time: " << startTime << std::endl;
//         Rcpp::Rcout << "End Date: " << endDate << std::endl;
//         Rcpp::Rcout << "End Time: " << endTime << std::endl;
//         Rcpp::stop("Error retrieving time series data");
//     }

//     // Convert timeArray to Rcpp::Datetime
//     std::vector<Rcpp::Datetime> datetimeArray = date_times_from_julian_array(timeArray, timeGranularitySeconds, julianBaseDate);

//     // Filter out undefined values
//     std::vector<Rcpp::Datetime> filteredTimeArray;
//     std::vector<double> filteredValueArray;
//     for (int i = 0; i < numberValuesRead; ++i) {
//         //if (valueArray[i] != DSS_UNDEFINED_VALUE) {
//             filteredTimeArray.push_back(datetimeArray[i]);
//             filteredValueArray.push_back(valueArray[i]);
//         //}
//     }

//     Rcpp::DataFrame df = Rcpp::DataFrame::create(Rcpp::Named("Time") = filteredTimeArray,
//                                                  Rcpp::Named("Value") = filteredValueArray);

//     // Set Units and Type as attributes
//     df.attr("Units") = units;
//     df.attr("Type") = type;

//     return df;
    
// }

// // [[Rcpp::export]]
// void store_timeseries(Rcpp::XPtr<dss_file> dss, std::string pathname, 
//                       std::string startDate, std::string startTime, 
//                       Rcpp::NumericVector valueArray, 
//                       Rcpp::IntegerVector qualityArray, 
//                       int saveAsFloat, std::string units, std::string type) {
//     int valueArraySize = valueArray.size();
//     int qualityArraySize = qualityArray.size();

//     if (valueArraySize != qualityArraySize) {
//         Rcpp::stop("Value array and quality array must have the same size");
//     }

//     int status = hec_dss_tsStoreRegular(dss.get(), pathname.c_str(), 
//                                         startDate.c_str(), startTime.c_str(), 
//                                         valueArray.begin(), valueArraySize, 
//                                         qualityArray.begin(), qualityArraySize, 
//                                         saveAsFloat, units.c_str(), type.c_str());

//     if (status != 0) {
//         Rcpp::stop("Error storing time series data");
//     }
// }

// // [[Rcpp::export]]
// void store_dataframe(Rcpp::XPtr<dss_file> dss, std::string pathname, Rcpp::DataFrame df, int saveAsFloat) {
//     // Extract the first Datetime object from the data frame
//     Rcpp::DatetimeVector timeVector = df["Time"];
//     Rcpp::Datetime startDateTime = timeVector[0];

//     // Format the Datetime object to get the start date and time
//     std::string startDate = format_datetime(startDateTime, "%d%b%Y");
//     std::string startTime = format_datetime(startDateTime, "%H:%M:%S");

//     Rcpp::Rcout << "startDate: " << startDate << std::endl;
//     Rcpp::Rcout << "startTime: " << startTime << std::endl;

//     // Extract the values and quality arrays from the data frame
//     Rcpp::NumericVector valueArray = df["Value"];
//     Rcpp::IntegerVector qualityArray = df.containsElementNamed("Quality") ? df["Quality"] : Rcpp::IntegerVector(valueArray.size(), 0);

//     // Extract units and type from the DataFrame attributes
//     std::string units = Rcpp::as<std::string>(df.attr("Units"));
//     std::string type = Rcpp::as<std::string>(df.attr("Type"));

//     // Call the store_timeseries function to store the data in the DSS file
//     store_timeseries(dss, pathname, startDate, startTime, valueArray, qualityArray, saveAsFloat, units, type);
// }

void close_dss(dss_file* dss) {
    hec_dss_close(dss);
}
