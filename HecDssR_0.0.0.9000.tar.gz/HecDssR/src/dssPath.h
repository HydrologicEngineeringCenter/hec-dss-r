#ifndef DSSPATH_H
#define DSSPATH_H

#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <Rcpp.h>
#include "recordType.h"

class DssPath {
public:
    DssPath(const std::string& path, RecordType recType = RecordType::Unknown);

    bool operator==(const DssPath& other) const;

    std::string toString() const;

    DssPath pathWithoutDate() const;

    bool isTimeSeries() const;

    void print() const;

    std::string getD() const;

    void setD(const std::string& d);

private:
    std::string A, B, C, D, E, F;
    RecordType recType;
    std::vector<std::string> parts;

    void split(const std::string& str, char delimiter);

    static const std::vector<RecordType> timeSeriesFamily;
};

#endif // DSSPATH_H
