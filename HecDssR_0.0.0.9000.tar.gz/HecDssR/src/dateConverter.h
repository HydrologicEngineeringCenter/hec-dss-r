#ifndef DATECONVERTER_H
#define DATECONVERTER_H

#include <Rcpp.h>
#include <vector>
#include <string>

// Function declarations
std::vector<Rcpp::Datetime> date_times_from_julian_array(const std::vector<int>& times_julian, 
                                                         int time_granularity_seconds, 
                                                         int julian_base_date);

std::vector<int> julian_array_from_date_times(const std::vector<Rcpp::Datetime>& date_times, 
                                              int time_granularity_seconds = 60, 
                                              const Rcpp::Datetime& start_date_base = Rcpp::Datetime("1900-01-01 00:00:00"));

std::string format_datetime(const Rcpp::Datetime& datetime, const char* format="%Y-%m-%d %H:%M:%S");

#endif // DATECONVERTER_H
